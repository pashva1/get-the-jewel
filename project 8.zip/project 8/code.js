var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["1610f7a6-f61a-477d-90c3-bc6d74a43e3f","ad9d56b2-a602-4fbd-bd1e-401a2464f01a","b1772e90-3200-41d9-bfda-915bad002fd7","fe425469-f2d5-471f-bc56-5f95859a7a87","fe2ce0de-5f9e-4973-937b-4cc42f323b56","589e7e6d-7e69-4d8d-9dfb-2c99229e7885","7fe8cb83-4578-4b2b-9657-a97bf200e3f8"],"propsByKey":{"1610f7a6-f61a-477d-90c3-bc6d74a43e3f":{"name":"alienBeige_climb_1","sourceUrl":"assets/api/v1/animation-library/gamelab/tROxV.Ws7RkaYVqR0pEqvHElelSLCoIL/category_characters/alienBeige_climb.png","frameSize":{"x":68,"y":97},"frameCount":2,"looping":true,"frameDelay":2,"version":"tROxV.Ws7RkaYVqR0pEqvHElelSLCoIL","loadedFromSource":true,"saved":true,"sourceSize":{"x":136,"y":97},"rootRelativePath":"assets/api/v1/animation-library/gamelab/tROxV.Ws7RkaYVqR0pEqvHElelSLCoIL/category_characters/alienBeige_climb.png"},"ad9d56b2-a602-4fbd-bd1e-401a2464f01a":{"name":"kid_25_1","sourceUrl":"assets/api/v1/animation-library/gamelab/eYAi8PnfxPF649j6FN2CHIBesugtr_cg/category_characters/kid_25.png","frameSize":{"x":192,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"eYAi8PnfxPF649j6FN2CHIBesugtr_cg","loadedFromSource":true,"saved":true,"sourceSize":{"x":192,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/eYAi8PnfxPF649j6FN2CHIBesugtr_cg/category_characters/kid_25.png"},"b1772e90-3200-41d9-bfda-915bad002fd7":{"name":"wood_red_1","sourceUrl":"assets/api/v1/animation-library/gamelab/8ztia436J1dv53q3abNzklHN0peISdI9/category_environment/wood_red.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":"8ztia436J1dv53q3abNzklHN0peISdI9","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/8ztia436J1dv53q3abNzklHN0peISdI9/category_environment/wood_red.png"},"fe425469-f2d5-471f-bc56-5f95859a7a87":{"name":"bronze_1","sourceUrl":"assets/api/v1/animation-library/gamelab/dZ98jetKnt5ZogX102g5XO3252U0D8oc/category_gameplay/bronze.png","frameSize":{"x":86,"y":86},"frameCount":6,"looping":true,"frameDelay":2,"version":"dZ98jetKnt5ZogX102g5XO3252U0D8oc","loadedFromSource":true,"saved":true,"sourceSize":{"x":516,"y":86},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dZ98jetKnt5ZogX102g5XO3252U0D8oc/category_gameplay/bronze.png"},"fe2ce0de-5f9e-4973-937b-4cc42f323b56":{"name":"fence_wood_1","sourceUrl":"assets/api/v1/animation-library/gamelab/paRBZ1IDgpB8JjI8z4sBpRGSRUCCQLC2/category_obstacles/fence_wood.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":"paRBZ1IDgpB8JjI8z4sBpRGSRUCCQLC2","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/paRBZ1IDgpB8JjI8z4sBpRGSRUCCQLC2/category_obstacles/fence_wood.png"},"589e7e6d-7e69-4d8d-9dfb-2c99229e7885":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"d_a8QT2aAViCd9Ff1nX9P1PlRI9Sp4ti","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/589e7e6d-7e69-4d8d-9dfb-2c99229e7885.png"},"7fe8cb83-4578-4b2b-9657-a97bf200e3f8":{"name":"win","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"vSFsPiKKbthCYsLRU_pE1C53CHdfcmyN","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/7fe8cb83-4578-4b2b-9657-a97bf200e3f8.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var bg=createSprite(200,200,400,400);
bg.setAnimation("wood_red_1");
bg.scale=3;

var robber=createSprite(30,350,10,10);
robber.setAnimation("kid_25_1");
robber.scale=0.2;

var coin=createSprite(345,30,10,20);
coin.setAnimation("bronze_1");
coin.scale=0.5;

var obstacle1=createSprite(220,240,150,10);
obstacle1.velocityX=4;

var obstacle2=createSprite(115,195,10,150);
obstacle2.velocityY=4;

var obstacle3=createSprite(290,195,10,150);
obstacle3.velocityY=4;

var obstacle4=createSprite(345,195,150,10);
obstacle4.velocityX=4;

var gamestate="play";

function draw() {
  background("white");
  
  if(gamestate==="play"){
    if(robber.isTouching(obstacle1)||robber.isTouching(obstacle2)
       ||robber.isTouching(obstacle3)||robber.isTouching(obstacle4)){
         gamestate="end";
       }
  }
  else if(gamestate==="end"){
  robber.setVelocity(0,0);
  obstacle1.setVelocity(0,0);
    obstacle2.setVelocity(0,0);
    obstacle3.setVelocity(0,0);
    obstacle4.setVelocity(0,0);
    
    var gameover=createSprite(173,100);
    gameover.setAnimation("animation_1");
    gameover.scale=2;
  }
  
  createEdgeSprites();
  
  obstacle1.bounceOff(leftEdge);
   obstacle1.bounceOff(rightEdge);
   
   obstacle2.bounceOff(topEdge);
   obstacle2.bounceOff(bottomEdge);
   
   obstacle3.bounceOff(topEdge);
   obstacle3.bounceOff(bottomEdge);
   
   obstacle4.bounceOff(leftEdge);
   obstacle4.bounceOff(rightEdge);
  
      robber.bounceOff(topEdge);
     robber.bounceOff(bottomEdge);
    robber.bounceOff(leftEdge);
    robber.bounceOff(rightEdge);
  
      if(keyDown(DOWN_ARROW)){
        robber.velocityY=3;
      }
         if(keyDown(UP_ARROW)){
        robber.velocityY=-3;
      }
       if(keyDown(LEFT_ARROW)){
        robber.velocityX=-3;
       }
       if(keyDown(RIGHT_ARROW)){
        robber.velocityX=3;
       }
      if(robber.isTouching(coin)){
        var win=createSprite(200,200);
        win.setAnimation("win");
        win.scale=2;
        robber.setVelocity(0,0);
         obstacle1.setVelocity(0,0);
         obstacle2.setVelocity(0,0);
         obstacle3.setVelocity(0,0);
         obstacle4.setVelocity(0,0);
      }
       
       if(obstacle1.isTouching(robber)||obstacle2.isTouching(robber)||
       obstacle3.isTouching(robber)||obstacle4.isTouching(robber)){
         textSize(20);
         text("robber has been caught",190,140);
         text("press R to restart",190,160);
         robber.setVelocity(0,0);
         obstacle1.setVelocity(0,0);
         obstacle2.setVelocity(0,0);
         obstacle3.setVelocity(0,0);
         obstacle4.setVelocity(0,0);
       }
  drawSprites();
  
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
